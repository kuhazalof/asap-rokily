$('.startPanel button').on('click', e => {
    var word = (e.target.id);
    socket.emit("word" , word );
    $(".startPanel").css("display", "none");
    $("#selectedWord").html(word);
    stopPanelTimer();
    startTimer();
    $(".front").css('display', 'none') 
});
