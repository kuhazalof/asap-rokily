var canv = document.getElementById("canvas"),
    ctx = canv.getContext("2d"),
    data,
    coords = [],
    myColor = "black",
    colorButtons = document.querySelectorAll('.itemColor'),
    clear = function () { 
        ctx.fillStyle = "white";
        ctx.fillRect(0,0,canv.width,canv.height);
        ctx.beginPath();
        ctx.fillStyle = myColor;
     },
    isMouseDown = false;
    


document.getElementById('color').oninput = function () {    
    myColor = this.value;
}

document.getElementById('clear').onclick = ()=>{
    clear();
}

colorButtons.forEach(element => {
    element.addEventListener("mousedown", function () {    
        myColor = this.id;
    })
});


canv.addEventListener("mousedown" , () => {
    isMouseDown = true;
});

canv.addEventListener("mouseup" , () => {
    isMouseDown = false;
    coords.push("mouseup");
    ctx.beginPath();
    data = {
        coords : coords
    }     
    mouseDragged(data);
});

canv.width = 600 ;
canv.height = 600  ;

ctx.lineWidth = 20;

socket.on("mouse", (data) => {

        if(!data.coords.length){
            ctx.beginPath();
            return;
        }
            for (let index = 0; index < data.coords.length; index++) {
                const element = data.coords[index];
                if(element==="mouseup"){
                    ctx.beginPath(); 
                }else{
                    let x = element[0];
                    let y = element[1];
                    ctx.lineTo(x,y);
                    ctx.stroke();
                    ctx.beginPath();  
                    ctx.arc(x,y, 10, 0 , Math.PI * 2);
                    ctx.fill();
                    ctx.beginPath();
                    ctx.moveTo(x,y);
                }
            }
    }
);

canv.addEventListener("mousemove" , (e) => {

    if (isMouseDown) {
       
        var x = (e.offsetX === undefined) ? e.layerX : e.offsetX;
        var y = (e.offsetY === undefined) ? e.layerY : e.offsetY;
        coords.push([x,y]);
        ctx.strokeStyle = myColor
        ctx.lineTo(x,y);
        ctx.stroke();

        ctx.beginPath();  
        ctx.arc(x,y, 10, 0 , Math.PI * 2);
        ctx.fillStyle = myColor
         ctx.fill();

        ctx.beginPath();
        ctx.moveTo(x,y);

     
        
      }
});