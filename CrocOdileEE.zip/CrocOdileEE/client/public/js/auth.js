var socket = io.connect(window.location.href);
var roomSocket = io.connect("http://localhost:7777");
var roomUrlArray = [];

roomSocket.on('roomsUrl', function (rooms) {
    
    rooms.forEach((element,index) =>{
        roomUrlArray[index] = element;
        
    });
    
});

var getMeRandomElements = function(sourceArray, neededElements) {
    var result = [];
    for (var i = 0; i < neededElements; i++) {
        var ind =Math.floor(Math.random()*sourceArray.length);
        result.push(sourceArray[ind]);
        sourceArray.splice(ind, 1);
    }    
    return result;
}
function randomRoom(rooms) {
    var ind = Math.floor(Math.random()*rooms.length);
        return rooms[ind].name;
}


var wordsArray = ["Камера", "Кружка", "Флаг", "Карандаш", "Пожарный", "Дровосек",
                  "Краб", "Морская звезда", "Страус", "Божья коровка", "Пеликан",
                    "Гусеница", "Паук", "Динозавр", "Медуза", "Улитка", "Apple","Кентавр",
                    "Гейша", "Терминатор", "Трансвестит", "Бэтмен", "Русалка", "Гном", "Колобок",
                    "Аватар", "Человек-паук"];

function response (data) {
    let resp = data.responseText;
    try {
        if (data.message != void (0)) {
            resp = data.message;
        } else {
            resp = JSON.parse(data.responseText);
            resp = resp.message;
        }
    } catch (e) {}
    return resp;
}

$(".logout-btn").on('click', e => {
    e.preventDefault();
    $.ajax({
        url: '/logout',
        type: 'POST',
        data: {},
        success: (res) => {
            //alert(response(res));
            window.location.href = "/";
        },
        error: (res) => {
            alert(response(res));
        }
    });   
});



socket.on("romIsFool" , ()=>{
    window.location.href = "/"+randomRoom(roomUrlArray);
});
socket.on("StartGame" , (s) => {
  
    var buttons = $('.word');
    var i = 0;
    var threeWords = getMeRandomElements(wordsArray,3);
    
   for (var button of buttons) {
    button.innerHTML = threeWords[i];
    $(button).attr("id",threeWords[i]);
    i++;
   }
   $("#timeUp").html("");
   $(".startPanel").css('display', 'block');
   startPanelTimer();
   $('.chat-message button').attr("disabled", "disabled");
  
});

socket.on("endGame", (word) => {
    $("#timeUp").html(word);
    $(".alonePanel").css('display', 'block') 
    setTimeout(()=>{
        $("#timeUp").html("");
        $(".alonePanel").css('display', 'none') 
    },3000);
    $(".front").css('display', 'block') 
    $('.chat-message button').removeAttr("disabled");
    $(".startPanel").css('display', 'none')
    $("#selectedWord").html("");
    stopTimer();
    ctx.clearRect(0, 0, canv.width, canv.height);
    ctx.beginPath(); 
    ctx.fillStyle  = "black";   
});

function mouseDragged(data) {
    socket.emit("mouse" , data);
}
function addInRoom(user) {
    var room = $(".chat-num-users");
    var html = `<div class="user"> <span class="name">${user}</span></div>`;

    $(html).appendTo(room);

}
socket.on("nowInRoom", (arr)=> {
    console.log("nowInRoom");
    
    setTimeout(() => {
        var room = $(".chat-num-users");
        room.empty();
        arr.forEach(element => {
        addInRoom(element[0]);
    });
    }, 0);
});
 

$( document ).ready( () => {  
  
    
    $("#skip").on("click", ()=>{
        socket.emit("skip", null);
    });
    
    $(window).on("beforeunload", (evt) => {
        socket.emit("logout" , socket.id);
	});
    
    socket.on('connect', function (e) {
               
        //socket.emit('receiveHistory');
       /*  */
    });
    $(".link").each(function( index ) {
        $(this).val(window.location.href);
      });
   
    socket.on("alone", ()=>{
        console.log("alone");
        $(".alonePanel").css('display', 'block') 
    });

    socket.on("leaveRoom", (username)=> {
      
        
       var rooms = $(".name");       
       rooms.each(function( index ) {
            if(( $( this ).text() )===username){
                
                $( this ).remove();
            }
          });
    });

    socket.on('message', addMessage);

    
    
    $('.chat-message button').on('click', e => {
        e.preventDefault();
       
        var selector = $("input[name='message']");
        var messageContent = selector.val().trim();
        
        if(messageContent !== '') {
            socket.emit('msg', messageContent);
            selector.val('');
        }
    });
    
    function encodeHTML (str){
        return $('<div />').text(str).html();
    }
   
    function addMessage(message) {
        message.username  = encodeHTML(message.username);
        message.content   = encodeHTML(message.content);

        var html = `
            <li class = "list-group-item-info">
                <div class="message-data">
                    <span class="message-data-name" dir="auto">${message.username} : ${message.content}</span>
                </div>
            </li>`;

        $(html).hide().appendTo('.chat-history ul').slideDown(200);

        $(".chat-history").animate({ scrollTop: $('.chat-history')[0].scrollHeight}, 1000);
    }
});