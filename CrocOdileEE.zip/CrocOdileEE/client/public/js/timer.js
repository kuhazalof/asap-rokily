var start = false;
var startPanel = false;
function startTimer() {
    if(!start){
        var my_timer = document.getElementById("my_timer");
        my_timer.innerHTML = "02:00"
        my_timer.style.display = "block";
        start = true;
        TicTimer();
    }
};
function stopTimer() {
    start= false;
    var my_timer = document.getElementById("my_timer");
        my_timer.innerHTML = "02:00"
        my_timer.style.display = "none";
};

function TicTimer() {
    if(start){
    var my_timer = document.getElementById("my_timer");
    var time = my_timer.innerHTML;
    var arr = time.split(":");
    //var h = arr[0];
    var m = arr[0];
    var s = arr[1];
    if (s == 0) {
      if (m == 0) {
          socket.emit("timeUp");
          start = false;
          return;
      }
      m--;
      if (m < 10) m = "0" + m;
      s = 59;
    }
    else s--;
    if (s < 10) s = "0" + s;
    document.getElementById("my_timer").innerHTML = m+":"+s;
    setTimeout(TicTimer, 1000);
    }
};


function startPanelTimer() {
    if(!startPanel){
        var my_timer = document.getElementById("timerStartPanel");
        my_timer.innerHTML = "10"
        my_timer.style.display = "block";
        startPanel = true;
        TicPanelTimer();
    }
};
function stopPanelTimer() {
    startPanel= false;
    var my_timer = document.getElementById("timerStartPanel");
        my_timer.innerHTML = "10"
        my_timer.style.display = "none";
};

function TicPanelTimer() {
    if(startPanel){
    var my_timer = document.getElementById("timerStartPanel");
    var time = my_timer.innerHTML;
    var arr = time.split();;
    var s = arr[0];
    if (s == 0) {
          socket.emit("skip");
          startPanel = false;
          return;
    }
    else s--;
    if (s < 10) s = "0" + s;
    document.getElementById("timerStartPanel").innerHTML = s;
    setTimeout(TicPanelTimer, 1000);
    }
};