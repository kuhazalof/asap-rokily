$("#button-addon2").on("click", ()=> {
  var input = $("#link");   
   console.log("copy");
   input.focus();
   document.execCommand('SelectAll');
   document.execCommand("Copy", false, null);
   input.blur();
})