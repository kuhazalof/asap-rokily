"use stict";

const MessageModel = require('./models/messages.model');
const UserCount= require('./models/users.model');
var checkAuth = require("./chechAuth");
const cookieParser = require('cookie-parser');
const passport = require('passport');
const config = require('./config');
var uuid = require('uuid-v4');
var roomUrlArray = [];
var gameIsStart = false;
var roomAndUser = {};
var word = null;
function auth (socket, next) {

    // Parse cookie
    cookieParser()(socket.request, socket.request.res, () => {});

    // JWT authenticate
    passport.authenticate('jwt', {session: false}, function (error, decryptToken, jwtError) {
        if(!error && !jwtError && decryptToken) {
            next(false, {username: decryptToken.username, id: decryptToken.id});
        } else {
            next('guest');
        }
    })(socket.request, socket.request.res);

}
function createNamespace(roomUrl,io) {
        var group = io.of("/"+roomUrl);
        var room = uuid();
        var arrSockets = [];
        
        group.on('connection', function (socket) {            
            //room = socket.handshake.headers.referer;
            
            socket.on("mouse", (data) =>{
                    socket.broadcast.to(room).emit("mouse" , data); 
            });
            socket.on("word" , (data) => {
                    word = data.toLowerCase();
            });
            if (arrSockets.length === 5){
                socket.emit("romIsFool" , null);
            }else{
                auth(socket, (guest, user) => {
                    
                    if(!guest) {
                        socket.join(room);
                        console.log("socket.join");
                        socket.username = user.username;
                        socket.resolution = false;

                        const obj = {
                            date: new Date(),
                            content: "connected to chat ",
                            username: user.username
                        };

                        MessageModel.create(obj, err => {
                        if(err) return console.error("MessageModel", err);
                            socket.to(room).emit("message", obj);
                        });
                        
                        
                        roomAndUser= [socket.username , socket.id , socket.resolution];
                      
                        var roomLeng = socket.adapter.rooms[room];
                       
                        var found = arrSockets.find(function(el) {
        
                            if (el[0] === roomAndUser[0]) {
                                    el[1] = socket.id;
                                    return true;
                                }
                        });
                        if (found){
                            
                        }else{
                            arrSockets.push(roomAndUser);
                        }
                        
                        console.log( roomUrl +" arrr"  );
                        console.log(arrSockets);
                        if (arrSockets.length === 2) {
                            if(!gameIsStart){
                                gameIsStart = true; 
                                arrSockets[0][2] = true;
                                socket.to(arrSockets[0][1]).emit('StartGame', null);
                            } 
                        }
                        if (arrSockets.length <= 1) {
                            group.to(room).emit("alone", arrSockets);
                        }
                        
                        group.to(room).emit("nowInRoom", arrSockets);
                    }      
                 });
            }
            
           
            socket.on("timeUp" , () => {
                const obj = {
                    date: new Date()
                };
                
                gameIsStart = false;
                group.to(room).emit("endGame", word);
                var randomUser = Math.floor(Math.random() * arrSockets.length);
                while (arrSockets[randomUser][1]===socket.id) {
                    randomUser = Math.floor(Math.random() * arrSockets.length);
                }
                setTimeout(()=>{
                        gameIsStart = true;
                        obj.content = "user " +arrSockets[randomUser][0] +" загадывает слово";
                        obj.username = "Система"  
                        MessageModel.create(obj, err => {
                            if(err) return console.error("MessageModel", err);
                            io.to(room).emit("message", obj);
                        })
                        socket.to(arrSockets[randomUser][1]).emit('StartGame', null);
                        arrSockets[randomUser][2] = true;
                        },3500);
            });
    
            socket.on("skip" , () => {
                const obj = {
                    date: new Date()
                };
                
                gameIsStart = false;
                group.to(room).emit("endGame", null);
                var randomUser = Math.floor(Math.random() * arrSockets.length);
                while (arrSockets[randomUser][1]===socket.id) {
                    randomUser = Math.floor(Math.random() * arrSockets.length);
                }
                setTimeout(()=>{
                        gameIsStart = true;
                        obj.content = "user " +arrSockets[randomUser][0] +" загадывает слово";
                        obj.username = "Система"  
                        MessageModel.create(obj, err => {
                            if(err) return console.error("MessageModel", err);
                            group.to(room).emit("message", obj);
                        })
                        socket.to(arrSockets[randomUser][1]).emit('StartGame', null);
                        arrSockets[randomUser][2] = true;
                        },500);
                        
            });
    
    
            socket.on("logout", (idSocket) =>{
                socket.leave(room);
    
                arrSockets.forEach((element,index) => {
                    if (element[1]=== idSocket){
                        arrSockets.splice(index,1);
                        if (element[2] === true) {
                            if (arrSockets.length >= 2) {
                                var randomUser = Math.floor(Math.random() * arrSockets.length);
                                gameIsStart = false;
                                group.to(room).emit("endGame", null);
                                setTimeout(()=>{
                                     
                                gameIsStart = true;
                                obj.content = "user " +arrSockets[randomUser][0] +" загадывает слово";
                                obj.username = "Система"  
                                MessageModel.create(obj, err => {
                                    if(err) return console.error("MessageModel", err);
                                    group.to(room).emit("message", obj);
                                })
                                socket.to(arrSockets[randomUser][1]).emit('StartGame', null);
                                arrSockets[randomUser][2] = true;
                                },500);
                            }
                            
                        }
                    }
                });           
                
                if (arrSockets.length <2){
                    gameIsStart = false;
                    group.to(room).emit("endGame", null);
                }
    
                const obj = {
                    date: new Date(),
                    content: socket.username + " leave chat " ,
                    username: "Система"
                };
                if(socket.username !== undefined){
                    MessageModel.create(obj, err => {
                        if(err) return console.error("MessageModel", err);
                        group.to(room).emit("message", obj);
                    });
                    group.to(room).emit("leaveRoom", socket.username);
                }
                
            });
    
    
            socket.on('msg', content => {
                const obj = {
                    date: new Date(),
                    content: content,
                    username: socket.username
                };
                
                MessageModel.create(obj, err => {
                    if(err) return console.error("MessageModel", err);
                    //socket.emit("message", obj);
                    group.to(room).emit("message", obj);
                });
                
                if(gameIsStart){
                    if (obj.content === word){
                        gameIsStart = false;
                        setTimeout(() => {
    
                            arrSockets.forEach(element => {
                                element[2] = false;
                            });
    
                            obj.content = "user " +socket.username +" отгадал слово " + word;
                            obj.username = "Система"                                                
                            MessageModel.create(obj, err => {
                            if(err) return console.error("MessageModel", err);
                            //socket.emit("message", obj);
                            group.to(room).emit("message", obj);
                            })
    
                            group.to(room).emit("endGame", word);
    
                        } , 500);
    
                        setTimeout(() => {
                            
                            obj.content = "user " +socket.username +" загадывает слово";
                            obj.username = "Система"  
    
                            arrSockets.forEach(element => {
                               if (element[0] === socket.username) {
                                element[2] = true;
                               }
                            });
                            MessageModel.create(obj, err => {
                                if(err) return console.error("MessageModel", err);
                           
                                group.to(room).emit("message", obj);
                            })
                            gameIsStart = true;
                        }, 3000);
                        setTimeout(()=> {
                            group.to(socket.id).emit('StartGame', gameIsStart);      
                        }, 3200);
                    }
                }
            });
    
        
            socket.on('disconnect', function () {
                
            });
        });
}

module.exports = (io,app) => {     
     var countUser = 0; 

        (function foo() {
            UserCount.count((err,c)=>{
                countUser = c;
                console.log(countUser);
                for (let index = 0; index < countUser/4; index++) {
         
                    roomUrlArray[index] = {
                        name: uuid()
                    }
                     
                 }   
                 roomUrlArray.forEach(element => {
                    createNamespace(element.name,io);
                });
                

            }); 
            MessageModel.remove({}).exec();  
        setTimeout(foo, 60 * 60 * 1000);
        })();
        
        io.on('connection', function (socket) {
                socket.emit('roomsUrl', roomUrlArray);
        }); 
        
        app.get('/:chat', checkAuth,  (req, res) => {
                    name = req.url.substring(1);
                    roomUrlArray.forEach(element => {
                            if(element.name === name){
                                res.render('chat.html', {});
                            }else{
                                if(name !== "favicon.ico"){
                                    res.render('index.html',  { error: "Room not found" } );
                                }
                            }
                    });
                                       
            });
         
       
    
};